<!-- Footer -->
<footer class="main">
	&copy; <?php echo date('Y')?> | Kilama Pre & Primary English Medium School, Pupils Management System (PMS) - Developed by JOHN JOSEPH +255 (0) 788-460-536 / +255 (0) 655-460-536 </strong>
</footer>
